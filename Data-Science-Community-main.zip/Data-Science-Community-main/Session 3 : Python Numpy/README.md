# Session 3 : Python Numpy

In the 3rd session, I took a hand-on approach to learning the python library for statistics called 'Numpy'. You can find the python notebook used in the session in 'Session 3' sub repository.

<p align="center">
  <img src="https://raw.githubusercontent.com/gohil-jay/Data-Science-Community/main/Session%203%20%3A%20Python%20Numpy/Screenshot.png" alt="Screenshot" />
</p>
