# Session 1-2: QnA

During the first two session for the community, I talked about various computer science roadmaps (including data science), explained different career pathways, and solved doubts & queires of students who didn't have any senior (mentor) to talk and clear their doubts with.

# Resources

Click here to go to <a href="https://github.com/gohil-jay/Data-Science-Community/tree/main/Resources" target="_blank">RESOURCES</a>
