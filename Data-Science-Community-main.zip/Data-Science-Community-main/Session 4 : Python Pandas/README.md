# Session 4 : Python Pandas

In the 4th session, I took a hand-on approach to learning the python library for statistics called 'Pandas'. You can find the python notebook used in the session in 'Session 4' sub repository.

<p align="center">
  <img src="https://raw.githubusercontent.com/gohil-jay/Data-Science-Community/main/Session%204%20%3A%20Python%20Pandas/Snapshot.png" alt="Screenshot" />
</p>
